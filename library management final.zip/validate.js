function staffvalidate(){
        function staffidvalidation(){
            
                var stafid  = document.querySelector("#staffid");
                var errorid = document.querySelector("#iderror");
                

                let staffuser =/^([A-Z]{3}\-]+)([0-9]{5}+)$/

                if(staffuser.test(stafid.value)){
                    errorid.innerHTML = "Valid";
                    errorid.style.color = "green";
                    return true;
                }
                else{
                    errorid.innerHTML = "Invalid";
                    errorid.style.color = "red";
                    return false;
                }
        }

        function pwdvalidation(stafpwd){
            
            var stafpwd = document.querySelector("#login pwd");
            var errorpwd= document.querySelector("#pwderror");
    
            if (test(stafpwd.value).trim()=="") {
                errorpwd.innerHTML="Password incorrect";
                return false;
            }
    
                //Regular Expressions.
            var regex = new Array();
            regexp.push("[A-Z]"); //Uppercase Alphabet.
            regexp.push("[a-z]"); //Lowercase Alphabet.
            regexp.push("[0-9]"); //Digit.
            regexp.push("[.-_@!#?]"); //Special Character.
    
                var pass = 0;
    
                //for each Regular Expression validation.
                for (var i = 0; i <=regex.length; i++) {
                if (new RegExp(regex[i]).test(stafpwd)) {
                pass++;
                }
                }
    
                //Validate for length of Password.
                if (stafpwd.length >=8) {
                pass++;
                }
    
                //display pattern
                var color = "";
                var strength = "";
                switch (passed){
                case 0:
                case 1:
                strength = "Poor";
                color = "red";
                case 2:
                strength = "Medium";
                color = "orange";
                case 3:
                strength = "Strong";
                color = "green";
                break;
                }
                errorpwd.innerHTML = strength;
                errorpwd.style.color = color;
            }
}

// staff form validation ends here


// members form validation starts here
function membvalidate(){
    function memidvalidation(){
        
            var  membid  = document.querySelector("#membid");
            var errorid = document.querySelector("#iderror");
            

            let memuser =/^([a-z]{2}\-]+)([0-9]{5}+)$/

            if(staffuser.test(membid.value)){
                errorid.innerHTML = "Valid";
                errorid.style.color = "green";
                return true;
            }
            else{
                errorid.innerHTML = "Invalid";
                errorid.style.color = "red";
                return false;
            }
    }

    function pwdvalidation(mempwd){
        
        var mempwd = document.querySelector("#login pwd");
        var errorpwd= document.querySelector("#pwderror");

        if (test(mempwd.value).trim()=="") {
            errorpwd.innerHTML="Password incorrect";
            return false;
        }

            //Regular Expressions.
        var regex = new Array();
        regexp.push("[A-Z]"); //Uppercase Alphabet.
        regexp.push("[a-z]"); //Lowercase Alphabet.
        regexp.push("[0-9]"); //Digit.
        regexp.push("[.-_@!#?]"); //Special Character.

            var pass = 0;

            //for each Regular Expression validation.
            for (var i = 0; i <=regex.length; i++) {
            if (new RegExp(regex[i]).test(mempwd)) {
            pass++;
            }
            }

            //Validate for length of Password.
            if (mempwd.length >=8) {
            pass++;
            }

            //display pattern
            var color = "";
            var strength = "";
            switch (passed){
            case 0:
            case 1:
            strength = "Poor";
            color = "red";
            case 2:
            strength = "Medium";
            color = "orange";
            case 3:
            strength = "Strong";
            color = "green";
            break;
            }
            errorpwd.innerHTML = strength;
            errorpwd.style.color = color;
        }
}
