const express = require('express');
const loginRouter = express.Router();

loginRouter.get('/',function(req,res){  
    res.render("login",{
            nav:[
                {link:'/signup',name:'SIGN-UP'}
            ],
                title:'Library Management System'
                // authors
            });        
});
// loginRouter.get('/:loginid',function(req,res){
//     const loginid = req.params.authorid
//     res.render("login",{
//         nav,
//         title:'Library Management System',
//         books: login[loginid]
//     });
// });    


module.exports = loginRouter;