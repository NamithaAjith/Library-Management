const express = require('express');
const booksRouter = express.Router();
function router(nav){
    var books=[
        {
            title:'The Lord of the Rings',
            author:'J. R. R. Tolkien',
            genre: 'Fantasy & Adventure',
            img: "TheLordoftheRings.jpg"
        },
        {
            title:'The Alchemist',
            author:'Paulo Coelho',
            genre: 'Novel',
            img: "alchemist.jpg"
        },
        {
            title:'Stay Hungry Stay Foolish',
            author:'Rashmi Bansal',
            genre: 'Inspirational Non-fiction',
            img: "stayhungrystayfoolish.jpg"
        }
    ]
    booksRouter.get('/',function(req,res){
            res.render("books",{
                nav,                 
                title:'Library Management System',
                books
            });
    });
    booksRouter.get('/:bookid',function(req,res){
        const bookid = req.params.bookid
        res.render("book",{
            nav,
                title:'Library Management System',
                book: books[bookid]
        });
    });    
    return booksRouter;
}



module.exports = router;
        