// const express = require('express');
// const addbookRouter = express.Router();

// addbookRouter.get('/',function(req,res){
//     res.render("addbook",{
//         nav,                 
//         title:'Library Management System',
//         addbook
//     });
// });



// module.exports = addbookRouter;
