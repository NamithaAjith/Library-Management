const express = require('express');
const signupRouter = express.Router();

signupRouter.get('/',function(req,res){  
    res.render("signup",{
            nav:[
                {link:'/login',name:'LOG-IN'},
            ],
                title:'Library Management System'
            });        
});

module.exports = signupRouter;