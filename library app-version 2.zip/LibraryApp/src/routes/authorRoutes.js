const express = require('express');
const authorsRouter = express.Router();

function router(nav){
    var authors=[
        {
            writer:'Arthur Conan Doyle',
            title:'Stories of Sherlock Holmes',
            genre: 'Detective fiction',
            img: "ArthurConanDoyle.jpg"
        },
        {
            writer:'Lalithambika Antharjanam',
            title:'Agnisakshi',
            genre: 'Novel',
            img: "Lalithambika.jpg"
        },
        {
                    
            writer:'Ruskin Bond',
            title:'Delhi is not far',
            genre: 'Novel',
            img: "ruskin bond.jpg"
        }
    ]
    authorsRouter.get('/',function(req,res){  
                res.render("authors",{
                    nav,
                    title:'Library Management System',
                    authors
                });        
                
        });
    authorsRouter.get('/:authorid',function(req,res){
                const authorid = req.params.authorid
                res.render("author",{
                    nav,
                    title:'Library Management System',
                    author: authors[authorid]
            });
        });    
    return authorsRouter;
}

module.exports = router;
