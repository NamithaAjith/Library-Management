const express = require('express');

const app = express();
const nav= [

        {link:'/books',name:'BOOKS'},
        {link:'/authors',name:'AUTHORS'},
        
];
const booksRouter = require('./src/routes/bookRoutes')(nav);
const authorsRouter = require('./src/routes/authorRoutes')(nav);
const loginRouter = require('./src/routes/loginRoutes');
const signupRouter = require('./src/routes/signupRoutes');
// const addbookRouter = require('./src/routes/addbookRoutes')(nav);



app.use(express.static('./public'))
app.set('view engine' , 'ejs');
app.set('views','./src/views');
app.use('/books',booksRouter);
app.use('/authors',authorsRouter);
app.use('/login',loginRouter);
app.use('/signup',signupRouter);
// app.use('/addbook',addbookRouter);



app.get('/',function(req,res){
        res.render("index",
        {
            nav:[
                {link:'/books',name:'BOOKS'},
                {link:'/authors',name:'AUTHORS'},
                {link:'/login',name:'LOG-IN'},
                {link:'/signup',name:'SIGN-UP'},
                {link:'/addbook',name:'ADDBOOKS'}

            ],
                title:'Library Management System'
        }); 
});

app.listen(3000);