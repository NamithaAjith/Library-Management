var logid = document.querySelector('#logid');
var logiderr = document.querySelector('#logiderr');
var logpwd = document.querySelector('#logpwd');
var logpderr= document.querySelector('#logpderr');


function logvalidate(){
    var logidexp = '/^([A-Z]{3}+)([0-9]{5}+)$/';
    
    if(logidexp.test(logid.value)){
        logiderr.innerHTML = "Valid";
        return true;
    }
    if (test(logpwd.value).trim()=="") {
        logpderr.innerHTML = "Password incorrect";
        return false;
    }

        //Regular Expressions.
        var logpdexp = new Array();
        logpdexp.push("[A-Z]"); //Uppercase Alphabet.
        logpdexp.push("[a-z]"); //Lowercase Alphabet.
        logpdexp.push("[0-9]"); //Digits.
        logpdexp.push("[.-_@!#?]"); //Special Character.

        var pass = 0;

        //for each Regular Expression validation.
        for (var i = 0; i <=logpdexp.length; i++) {
        if (new RegExp(logpdexp[i]).test(logpwd)) {
        pass++;
        }
        }

        //Validate for length of Password.
        if (logpwd.length >=8) {
        pass++;
        }

        //display pattern
        var color = "";
        var strength = "";
        switch (passed){
        case 0:
        case 1:
        strength = "Poor";
        color = "red";
        case 2:
        strength = "Medium";
        color = "yellow";
        case 3:
        strength = "Strong";
        color = "green";
        break;
        }
        logpderr.innerHTML = strength;
        logpderr.style.color = color;

    
}


    





        