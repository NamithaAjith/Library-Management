var fname = document.querySelector("#RegisterFormFirstName");
var lname = document.querySelector("#RegisterFormLastName");
var email = document.querySelector("#RegisterFormEmail");
var phn = document.querySelector("#RegisterPhonePassword");
var pwd = document.querySelector("#RegisterFormPassword");
var cpwd = document.querySelector("#cnfmpswd");


var error1=document.querySelector("#err1");
var error2=document.querySelector("#err2");
var error3=document.querySelector("#err3");
var error4=document.querySelector("#err4");
var error5=document.querySelector("#err5");
var error6=document.querySelector("#err6");

let expr = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
let nameexp =/^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
let phexp=/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
// let pwdexp=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/ 

function signvalidate(){
    
        return (verifyfname() && verifylname() && verifyemail() && verifyph() && verifypwd() && verifycnfrmpassword() ) ;
    
}

    
    function verifyfname(){
        if(nameexp.test(fname.value)){
            fname.style.border="2px solid green";
            return true;
        }
        else{
            error1.innerHTML="please enter your first name";
            fname.style.border="2px solid red";
            error1.style.color="red";
            return false;
        }   
    }

    function verifylname(){
            if(nameexp.test(lname.value))
            {
                lname.style.border="2px solid green";
                return true;
            }

            else{
                error2.innerHTML="please enter your last name";
                lname.style.border="2px solid red";
                error2.style.color="red";
                return false;
            }
    }

    function verifyemail(){
            if(expr.test(email.value)){
                email.style.border="2px solid green";
                return true;
            }
            else{
                error3.innerHTML="please enter a valid email address"
                email.style.border="2px solid red";
                error3.style.color="red";
                return false;
            }   
    }

    function verifyph(){
            if(phexp.test(phn.value))
            {
                phn.style.border="2px solid green";
                return true;
            }
            else{
                error4.innerHTML="phone number should be of 10 digits";
                phn.style.border="2px solid red";
                error4.style.color="red";
                return false;
            }
    }


    function verifypwd(){
            if (pwd.value.length <=8) {
                error5.innerHTML = "please enter password";
                error5.style.color="red";
                // error5.style.fontSize="large";
                return false;
            }
     
            //Regular Expressions.
            var regex = new Array();
            regex.push("[A-Z]"); //Uppercase Alphabet.
            regex.push("[a-z]"); //Lowercase Alphabet.
            regex.push("[0-9]"); //Digit.
            regex.push("[$@$!%*#?&]"); //Special Character.
     
            var passed = 0;
     
            //Validate for each Regular Expression.
            for (var i = 0; i < regex.length; i++) {
                if (new RegExp(regex[i]).test(pwd.value)) {
                    passed++;
                }
            }
     
            //Validate for length of Password.
            if (passed > 2 && pwd.value.length > 8) {
                passed++;
            }
            else{
            error5.innerHTML="password is invalid";
            error5.style.color="red";
            return false;
            }
     
            //Display status.
            var color = "";
            var strength = "";
            switch (passed) {
                case 0:
                case 1:
                    strength = "Weak";
                    color = "red";
                    break;
                case 2:
                    strength = "Good";
                    color = "darkorange";
                    break;
                case 3:
                case 4:
                    strength = "Strong";
                    color = "green";
                    break;
                case 5:
                    strength = "Very Strong";
                    color = "darkgreen";
                    break;
            }
            error5.innerHTML = strength;
            error5.style.color = color;
            
            
    }
                   
    function verifycnfrmpassword(){
            if(pwd.value != cpwd.value) {
            cpwd.setCustomValidity("Passwords Don't Match");
            error6.style.color="red";
            } 
            else {
            cpwd.setCustomValidity('');
            }
    }

    pwd.onchange = validatePassword;
    cpwd.onkeyup = validatePassword;

    function Toggle() { 
    if (pwd.type === "password") { 
        pwd.type = "text"; 
    } 
    else { 
        pwd.type = "password"; 
    } 
    } 