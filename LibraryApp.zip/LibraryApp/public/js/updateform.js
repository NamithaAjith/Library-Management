var title = document.querySelector("#title");
var author = document.querySelector("#author");
var work = document.querySelector("#work");
var genre = document.querySelector("#genre");
var img = document.querySelector("#img");



function validate(){
    if (title.value==""){       
        alert("Please enter your data !!!");
        return false;
    }
    if(author.value==""){
        alert("Please enter your data !!!");
        return false;
    }
    if(work.value==""){
        alert("Please enter your data !!!");
        return false;
    }
    if(genre.value==""){
        alert("Please enter your data !!!");
        return false;
    }
    else{
        return true;
    }
}
