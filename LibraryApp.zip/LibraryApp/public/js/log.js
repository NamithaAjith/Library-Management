var email = document.querySelector("#LoginFormEmail");
var pwd = document.querySelector("#LoginFormPassword");

var error1=document.querySelector("#Em-error");
var error2=document.querySelector("#Ps-error");

var expr = /^([A-Za-z0-9\-_.]+)@([A-Za-z0-9\-_.]+).([A-Za-z]{2,3})$/;

function logvalid(){
    return (verifyemail() && verifypaswd());


        function verifyemail(){
            if(expr.test(email.value)){
                email.style.border="2px solid green";
                return true;
            }
            else{
                error1.innerHTML="please enter a valid email address";
                email.style.border="2px solid red";
                error1.style.color="red";
                return false;
            }   
        }

        function verifypaswd(){
            if(pwd.value.length<8){
                error2.innerHTML="Wrong password.";
                error2.style.color="red";
                return false;
            }
            else{
                return true;
            }
        }
}