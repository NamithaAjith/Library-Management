
const express = require("express");
const signupRouter =  express.Router();

const  Members = require('../model/signupdata');

// signupRouter.get('/',function(req,res){  
//     res.render("signup",{
//             nav:[
//                 {link:'/login',name:'LOG-IN'},
//             ],
//                 title:'Library Management System'
//             });        
// });

function router(nav){
    
    signupRouter.get('/',function(req,res){
        res.render("signup",
        {
            nav,
            title:'Library Management System'
        });
    });

    signupRouter.post('/register', function(req, res){
        var item = {
            firstname : req.body.firstname,
            lastname: req.body.lastname,
            email : req.body.email,
            contact : req.body.contact,
            password : req.body.password,
            confirmpassword : req.body.confirmpassword
        }
        var signup = Members(item);
        signup.save();
        res.redirect('/login');
    });
    
    
    return signupRouter;  
}

module.exports = signupRouter;