
const express = require("express");
const loginRouter =  express.Router();
const  Memberslogin = require('../model/logindata');
const  Members = require('../model/signupdata');

 

function router(nav){
    
    loginRouter.get('/',function(req,res){
        res.render("login",
        {
            nav,
            title:'Library Management System',
            
        });
    });
    // loginRouter.post('/',function(req,res){  
    //     res.render("login",{
    //             nav:[
    //                 {link:'/signup',name:'SIGN-UP'}
    //             ],
    //                 title:'Library Management System',
    //             });        
    // });
    
    loginRouter.post('/validate',function(req,res){
        var email = req.body.email;
        var password = req.body.password;
        Members.findOne({email:req.body.email,
                    password:req.body.password},function(err,memb){
            
            if(!memb){
                res.redirect('/');
                return res.send("not found");
            }
            res.redirect('/index');
            return res.send("success");            
        })
    })
    return loginRouter;
    
}


module.exports = router;