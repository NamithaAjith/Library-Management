const express = require('express');
const addbookRouter = express.Router();
const Bookdata = require('../model/Bookdata');

function router(nav){
    addbookRouter.get('/',function(req,res){
        res.render("addbook",{
            nav,                 
            title:'Library Management System',
        });
    });
    addbookRouter.post('/add',function(req,res){
        var item = {
            title: req.body.title,
            author: req.body.author,
            genre: req.body.genre,
            img: req.body.img
        }     
            
        var book = Bookdata(item);
        // saving to the database
        book.save();  
        res.redirect('/books');
    });
    return addbookRouter;
}


module.exports = router;
