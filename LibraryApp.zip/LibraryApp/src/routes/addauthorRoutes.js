const express = require('express');
const addauthorRouter = express.Router();
const Authordata = require('../model/Authordata');

function router(nav){
    addauthorRouter.get('/',function(req,res){
        res.render("addauthor",{
            nav,                 
            title:'Library Management System',
        });
    });
    addauthorRouter.post('/add',function(req,res){
        var item = {
            author: req.body.author,
            work: req.body.work,
            awards: req.body.awards,
            img: req.body.img
        }     
            
        var author= Authordata(item);
        author.save();  
        res.redirect('/authors');
    });
    return addauthorRouter;
}


module.exports = router;
