// // const express = require('express');
// // const booksRouter = express.Router();
// // const Bookdata = require('../model/Bookdata');


// booksRouter.get('/:bookid/update', function(req, res){
        
//     const bookid = req.params.bookid;
//     Bookdata.findOne({_id:bookid})
//     .then(function(book){
//         res.render("updatebook",{
//         nav,
//         title:'Library Management System',
//         book
//     });
//     });
    
// });


// booksRouter.post('/:bookid/update/upload', function(req, res){
//     const bookid = req.params.bookid;
//     var item = {
//         title: req.body.title,
//         author: req.body.author,
//         genre: req.body.genre,
//         img: req.body.img
//     }     
//     var img = req.body.img;
//     if((req.body.image)==null){
//         img = req.body.img;
//     }
//     var book = Bookdata(item);
//     Bookdata.findByIdAndUpdate({_id:bookid},req.body,{new:true},)
//     .then(function(book){
//         res.redirect('/books');
//     });
// });


// booksRouter.get('/:bookid/delete',function(req,res){
//     const bookid = req.params.bookid;
//     Bookdata.findByIdAndDelete({_id:bookid})
//     .then(function(book){
//         res.redirect('/books');
//     });
// });   
// return booksRouter;
// }


// module.exports = router;