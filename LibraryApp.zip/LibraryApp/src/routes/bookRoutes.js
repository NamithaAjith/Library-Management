const express = require('express');
const booksRouter = express.Router();
const Bookdata = require('../model/Bookdata');

function router(nav){
    // var books=[
    //     {
    //         title:'The Lord of the Rings',
    //         author:'J. R. R. Tolkien',
    //         genre: 'Fantasy & Adventure',
    //         img: "TheLordoftheRings.jpg"
    //     },
    //     {
    //         title:'The Alchemist',
    //         author:'Paulo Coelho',
    //         genre: 'Novel',
    //         img: "alchemist.jpg"
    //     },
    //     {
    //         title:'Stay Hungry Stay Foolish',
    //         author:'Rashmi Bansal',
    //         genre: 'Inspirational Non-fiction',
    //         img: "stayhungrystayfoolish.jpg"
    //     }
    // ]
    booksRouter.get('/',function(req,res){
        Bookdata.find()
        .then(function(books){
            res.render("books",{
                nav,                 
                title:'Library Management System',
                books
            });
        });
            
    });
    booksRouter.get('/:bookid',function(req,res){
        const bookid = req.params.bookid
        Bookdata.findOne({_id:bookid})
        .then(function(book){
        res.render("book",{
            nav,
                title:'Library Management System',
                book
            });
        });
    }); 
    booksRouter.get('/:bookid/update', function(req, res){
        
        const bookid = req.params.bookid;
        Bookdata.findOne({_id:bookid})
        .then(function(book){
            res.render("updatebook",{
            nav,
            title:'Library Management System',
            book
        });
        });
        
    });

    
    booksRouter.post('/:bookid/update/upload', function(req, res){
        const bookid = req.params.bookid;
        var item = {
            title: req.body.title,
            author: req.body.author,
            genre: req.body.genre,
            img: req.body.img
        }     
        var img = req.body.img;
        if((req.body.image)==null){
            img = req.body.img;
        }
        var book = Bookdata(item);
        Bookdata.findByIdAndUpdate({_id:bookid},req.body,{new:true},)
        .then(function(book){
            res.redirect('/books');
        });
    });

   
   booksRouter.get('/:bookid/delete',function(req,res){
        const bookid = req.params.bookid;
        Bookdata.findByIdAndDelete({_id:bookid})
        .then(function(book){
            res.redirect('/books');
        });
    });   
    return booksRouter;
}


module.exports = router;
        