const express = require('express');
const authorsRouter = express.Router();
const Authordata = require('../model/Authordata');


function router(nav){
    // var authors=[
    //     {
    //         author:'Arthur Conan Doyle',
    //         work:'Stories of Sherlock Holmes',
    //         genre: 'Detective fiction',
    //         img: "ArthurConanDoyle.jpg"
    //     },
    //     {
    //         author:'Lalithambika Antharjanam',
    //         work:'Agnisakshi',
    //         genre: 'Novel',
    //         img: "Lalithambika.jpg"
    //     },
    //     {
                    
    //         author:'Ruskin Bond',
    //         work:'Delhi is not far',
    //         genre: 'Novel',
    //         img: "ruskin bond.jpg"
    //     }
    // ]
    authorsRouter.get('/',function(req,res){ 
        Authordata.find()
        .then(function(authors){ 
                res.render("authors",{
                    nav,
                    title:'Library Management System',
                    authors
                });
                });        
                
        });
    authorsRouter.get('/:authorid',function(req,res){
                const authorid = req.params.authorid
                Authordata.findOne({_id:authorid})
                .then(function(author){ 
                res.render("author",{
                    nav,
                    title:'Library Management System',
                    author
                });   
            });
        });    

    authorsRouter.get('/:authorid/update', function(req, res){
        
            const authorid = req.params.authorid;
            Authordata.findOne({_id:authorid})
            .then(function(author){
                res.render("updateauthor",
            {
                nav,
                title:'Library Management System',
                author
            });
            })
            
        });
    
    authorsRouter.post('/:authorid/update/upload', function(req, res){
            const authorid = req.params.authorid;
            var item = {
                author: req.body.author,
                work: req.body.work,
                awards: req.body.awards,
                img: req.body.img
            } ;
                
            var author = Authordata(item);
                 Authordata.findByIdAndUpdate({_id:authorid},req.body,{new:true})
            .then(function(author){
                res.redirect('/authors');
            });
        });
    
    
        authorsRouter.get('/:authorid/delete',function(req,res){
            const authorid = req.params.authorid;
            Authordata.findByIdAndDelete({_id:authorid})
            .then(function(author){
                res.redirect('/authors');
            });
        });
    
    return authorsRouter;
}

module.exports = router;
