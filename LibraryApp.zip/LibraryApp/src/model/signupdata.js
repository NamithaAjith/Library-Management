const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/library');


const Schema = mongoose.Schema;


const SignupSchema = new Schema({
    firstname : String,
    lastname : String,
    email : String,
    contact : Number,
    password : String,
    confirmpassword : String
});
    
//Model creation
var  Members = mongoose.model('member',SignupSchema);


module.exports = Members;