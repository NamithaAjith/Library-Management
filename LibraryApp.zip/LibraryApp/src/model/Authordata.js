const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/library'); //,{useunifiedTopology:true,useNewUrlParser:true}

// Schema definition
const Schema = mongoose.Schema;

const AuthorSchema = new Schema({
    
    author: String,
    work: String,
    awards: String,
    img: String
});


var Authordata = mongoose.model('authordata',AuthorSchema);
module.exports = Authordata;
